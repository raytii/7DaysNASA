let asteroids = [];
let allData = [];
let apiKey = "DEMO_KEY"; // Replace with your own key from api.nasa.gov
let isLoading = true;

const CONFIG = {
  noiseScale: 0.002,
  pathLength: 300,
  nodeCount: 150,
  globalAlphaMult: 1.4,
  colors: {
    far: { h: 185, s: 70, b: 60 },   // Deep Cyan
    near: { h: 330, s: 85, b: 100 }  // Vibrant Magenta
  }
};

function preload() {
  let today = new Date();
  let sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(today.getDate() - 7);
  let endStr = today.toISOString().split('T')[0];
  let startStr = sevenDaysAgo.toISOString().split('T')[0];
  
  let url = `https://api.nasa.gov/neo/rest/v1/feed?start_date=${startStr}&end_date=${endStr}&api_key=${apiKey}`;
  loadJSON(url, gotData, (err) => console.error("NASA API Error:", err));
}

function gotData(data) {
  let dateKeys = Object.keys(data.near_earth_objects);
  dateKeys.forEach(date => {
    data.near_earth_objects[date].forEach(obj => {
      if (obj.close_approach_data.length > 0) {
        allData.push({
          name: obj.name,
          diameter: obj.estimated_diameter.meters.estimated_diameter_max,
          velocity: parseFloat(obj.close_approach_data[0].relative_velocity.kilometers_per_second),
          distance: parseFloat(obj.close_approach_data[0].miss_distance.kilometers),
          isHazardous: obj.is_potentially_hazardous_asteroid
        });
      }
    });
  });

  allData = allData.slice(0, CONFIG.nodeCount);
  allData.forEach(d => asteroids.push(new CosmicStrand(d)));
  isLoading = false;
}

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  colorMode(HSB, 360, 100, 100, 1);
  setAttributes('alpha', true);
}

function draw() {
  background(5, 5, 8);

  if (isLoading) {
    drawLoading();
    return;
  }

  orbitControl();
  rotateY(frameCount * 0.0008);
  
  blendMode(ADD);
  asteroids.forEach(a => a.displayStrand());
  asteroids.forEach(a => {
    a.update();
    a.displayNode();
  });
  blendMode(BLEND);
  
  drawHUD();
}

class CosmicStrand {
  constructor(data) {
    this.data = data;
    this.path = [];
    this.speed = map(data.velocity, 0, 40, 0.2, 1.2);
    this.nodeSize = map(data.diameter, 0, 1000, 2, 8);
    this.zDepth = map(data.distance, 0, 80000000, -800, 400);

    // Initial cluster points to create spatial gaps
    let centerX = random(-width * 0.5, width * 0.5);
    let centerY = random(-height * 0.5, height * 0.5);
    let currentPos = createVector(centerX, centerY, this.zDepth);

    // Path Pre-calculation with Bezier Interpolation
    let cp1 = currentPos.copy();
    for (let i = 0; i < CONFIG.pathLength / 3; i++) {
      let angle1 = noise(cp1.x * CONFIG.noiseScale, cp1.y * CONFIG.noiseScale, this.zDepth) * TWO_PI * 4;
      let cp2 = p5.Vector.add(cp1, p5.Vector.fromAngle(angle1).mult(50));
      let angle2 = noise(cp2.x * CONFIG.noiseScale, cp2.y * CONFIG.noiseScale) * TWO_PI * 4;
      let endP = p5.Vector.add(cp2, p5.Vector.fromAngle(angle2).mult(50));
      
      for (let t = 0; t <= 1; t += 0.15) {
        let x = bezierPoint(cp1.x, cp2.x, endP.x, endP.x, t);
        let y = bezierPoint(cp1.y, cp2.y, endP.y, endP.y, t);
        let z = bezierPoint(cp1.z, cp2.z, endP.z, endP.z, t);
        this.path.push(createVector(x, y, z));
      }
      cp1 = endP.copy();
    }
    this.currentIndex = random(this.path.length);
  }

  update() {
    this.currentIndex = (this.currentIndex + this.speed) % this.path.length;
  }

  displayStrand() {
    noFill();
    for (let i = 0; i < this.path.length - 1; i += 2) {
      let p = this.path[i];
      let alpha = map(p.z, -800, 400, 0.02, 0.35, true);
      let hueVal = map(p.z, -800, 400, CONFIG.colors.far.h, CONFIG.colors.near.h, true);
      
      stroke(hueVal, 70, 100, alpha * CONFIG.globalAlphaMult);
      strokeWeight(map(p.z, -800, 400, 0.4, 1.2));
      if (alpha > 0.03) {
        line(p.x, p.y, p.z, this.path[i+1].x, this.path[i+1].y, this.path[i+1].z);
      }
    }
  }

  displayNode() {
    let p = this.path[floor(this.currentIndex)];
    let nodeAlpha = map(p.z, -800, 400, 0, 1, true);
    if (nodeAlpha > 0.1) {
      push();
      translate(p.x, p.y, p.z);
      let h = map(p.z, -800, 400, CONFIG.colors.far.h, CONFIG.colors.near.h, true);
      fill(this.data.isHazardous ? 0 : h, 80, 100, nodeAlpha);
      noStroke();
      sphere(this.nodeSize * 0.5, 4, 4);
      pop();
    }
  }
}

function drawHUD() {
  push();
  resetMatrix();
  translate(-width/2, -height/2);
  fill(0, 0, 100, 0.5);
  textFont('Courier New');
  textSize(12);
  text("NASA_NEO_ARCHIVE // STATUS: ACTIVE", 20, 30);
  text(`ENTITIES_LOGGED: ${asteroids.length}`, 20, 45);
  pop();
}

function drawLoading() {
  push();
  rotateX(frameCount * 0.05);
  stroke(180, 50, 100, 0.5);
  noFill();
  box(30);
  pop();
}

function windowResized() { resizeCanvas(windowWidth, windowHeight); }